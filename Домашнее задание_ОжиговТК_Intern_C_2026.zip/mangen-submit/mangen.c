#include <dirent.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <stdint.h>
#include <inttypes.h>
#include <fnmatch.h>
#include <locale.h>

struct back_type
{
    char** arr;
    size_t count;
};


static char *make_exclude_pattern(const char *pattern)
{
    size_t length = strlen(pattern);
    if (length > (SIZE_MAX - 1) / 2) {
        errno = EOVERFLOW;
        return NULL;
    }

    char *converted = malloc(length * 2 + 1);
    if (converted == NULL) {
        return NULL;
    }

    char *out = converted;
    for (size_t i = 0; i < length; ++i) {
        char ch = pattern[i];

        if (ch == '?' || ch == '[' || ch == '\\') {
            *out++ = '\\';
        }

        *out++ = ch == '.' ? '?' : ch;
    }
    *out = '\0';

    return converted;
}


//найти имена всех эл-ов в переданной дир-ии
struct back_type check(const char *drName, const char *exclude_pattern)
{
    //открываем папку
    DIR* dr = opendir(drName);
    if(dr == NULL)
    {
        perror("opendir");
        exit(1);
    }

    
    size_t cap = 8;
    size_t sz = 0;
    struct back_type answer;
    answer.arr = malloc(sizeof(char*)*cap);
    if(answer.arr == NULL)
    {
        perror("mallocCheck");
        exit(1);
    }

    errno = 0;
    struct dirent* s;
    s = readdir(dr);
    char* name_now;
    //считываем в массив переменное длины содержимое
    while(s != NULL)
    {
        name_now = s->d_name;
        int match = exclude_pattern == NULL
            ? FNM_NOMATCH
            : fnmatch(exclude_pattern, name_now, 0);

        if (match != 0 && match != FNM_NOMATCH) {
            fprintf(stderr, "Ошибка проверки шаблона для имени \"%s\"\n", name_now);
            exit(EXIT_FAILURE);
        }

        if (strcmp(name_now, ".") != 0 &&
            strcmp(name_now, "..") != 0 &&
            match == FNM_NOMATCH)
        {
            //расширяем размер, если это понадобилось 
            if(sz == cap)
            {
                cap *= 2;
                char** tmp = realloc(answer.arr, sizeof(char*)*cap);
                if(tmp == NULL) 
                {
                    perror("realloc");
                    exit(1);
                }
                answer.arr = tmp;
            }

            //выделим память под саму строку

            // printf("%s \n", s->d_name);
            size_t bytes = strlen(name_now) + 1;//+1 для символа конца строки
            char *copy = malloc(bytes);
            if (copy == NULL) 
            {
                perror("malloc");
                exit(EXIT_FAILURE);
            }
            for (size_t i = 0; i < bytes; i++) {
                copy[i] = name_now[i];
            }

            answer.arr[sz] = copy;
            sz++;
        }

        errno = 0;
        s = readdir(dr);
    }
    if (errno != 0)
    {
        perror("readdir\n");
        exit(1);
    }

    closedir(dr);
    answer.count = sz;

    return answer;
}


/**
 * функция для поиска хэша файла, алгоритм FNV‑1a на 32 бита
 */
int hash_file(const char *path, uint32_t *result)
{
    FILE *file = fopen(path, "rb");
    if (file == NULL) {
        return -1;
    }

    uint32_t hash = UINT32_C(0x811C9DC5);
    unsigned char buffer[4096];
    size_t bytes_read;

    do {
        bytes_read = fread(buffer, 1, sizeof buffer, file);

        for (size_t i = 0; i < bytes_read; ++i) {
            hash ^= buffer[i];
            hash *= UINT32_C(0x01000193);
        }
    } while (bytes_read == sizeof buffer);

    if (ferror(file)) {
        int read_error = errno;
        fclose(file);
        errno = read_error;
        return -1;
    }

    if (fclose(file) == EOF) {
        return -1;
    }

    *result = hash;
    return 0;
}

//рукурсивная функция обхода дерева, в глубину
void obhod(const char *startDir, const char *pathToPrint,
           const char *exclude_pattern)//путь для чтения и печати
{
    //DIR* dr = opendir(startDir);

    errno = 0;
    struct dirent* s;
    
    struct back_type ans = check(startDir, exclude_pattern);

    for (int i = 0; i < ans.count; i++)
    {
        
        struct stat info;  

        size_t len = strlen(startDir) + strlen(ans.arr[i]) + 2;
        char* newPath = malloc(len);
        if (newPath == NULL)
        {
            perror("mallocObhod");
            exit(1);
        }

        snprintf(newPath, len, "%s/%s", startDir, ans.arr[i]);

        if (lstat((const char*)newPath, &info) == -1)
        {
            perror("path");
            exit(1);
        }



        size_t lenToPathPrint = strlen(pathToPrint) + strlen(ans.arr[i]) + 2;
        char* newPathToPrint = malloc(lenToPathPrint);
        if (newPathToPrint == NULL)
        {
            perror("mallocObhod");
            exit(1);
        }
        if (strlen(pathToPrint) == 0){
            strcpy(newPathToPrint, ans.arr[i]);
        } else {
            snprintf(newPathToPrint, lenToPathPrint, "%s/%s", pathToPrint, ans.arr[i]);
        }



        if(S_ISDIR(info.st_mode)) 
        {
            //printf(" -- каталог\n");
            obhod(newPath, newPathToPrint, exclude_pattern);
        }
        if(S_ISREG(info.st_mode))
        {
            //printf(" -- файл ");
            uint32_t hash;
            int hasgReg = hash_file(newPath, &hash);
            if (hasgReg == -1)
            {
                perror("hash_file");
                exit(1);
            }
            printf("%s : %08" PRIX32 "\n", newPathToPrint, hash);
        }
        free(newPath);
        free(newPathToPrint);
    }
    for (int i = 0; i < ans.count; i++) free(ans.arr[i]);
    free(ans.arr);
}

//тут просто в зависимости от кол-ва аргументов в мейн делаем разные
/** действия
 * либо выполняем операцию, либо обход делаем 
 */
int main(int argc, char *argv[])
{
    const char *dir = NULL;
    const char *exclude_name = NULL;

    for (int i = 1; i < argc; ++i) {
        const char *arg = argv[i];

        if (strcmp(arg, "-h") == 0) {
            printf("Использование\n"
                   "  ./mangen [DIR_PATH] [OPTIONS]\n\n"
                   "Если DIR_PATH не указан, используется текущий каталог.\n\n"
                   "Опции\n"
                   "  -h       Показать справку и завершить работу.\n"
                   "  -v       Показать версию и завершить работу.\n"
                   "  -e ШАБЛОН  Исключить файлы и каталоги. . — один символ, * — любая последовательность.\n");
            return 0;
        }

        if (strcmp(arg, "-v") == 0) {
            printf("mangen 1.0.0\n");
            return 0;
        }

        if (strcmp(arg, "-e") == 0) {
            if (exclude_name != NULL || i + 1 == argc ||
                argv[i + 1][0] == '\0') {
                fprintf(stderr, "Укажи -e один раз с непустым именем.\n");
                return EXIT_FAILURE;
            }

            ++i;
            exclude_name = argv[i];
            continue;
        }

        if (arg[0] == '-' || dir != NULL) {
            fprintf(stderr, "Неожиданный аргумент: %s\n", arg);
            return EXIT_FAILURE;
        }

        dir = arg;
    }

    char *exclude_pattern = NULL;

    if (exclude_name != NULL) {
        setlocale(LC_CTYPE, "");

        exclude_pattern = make_exclude_pattern(exclude_name);
        if (exclude_pattern == NULL) {
            perror("make_exclude_pattern");
            return EXIT_FAILURE;
        }
    }

    obhod(dir != NULL ? dir : ".", "", exclude_pattern);
    free(exclude_pattern);
    return 0;
}

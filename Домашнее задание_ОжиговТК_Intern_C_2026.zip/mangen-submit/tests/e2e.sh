#!/bin/sh
set -eu

program="$PWD/mangen"
test_dir=$(mktemp -d)
trap 'rm -rf -- "$test_dir"' 0

# Создаём два файла с заранее известными хэшами.
mkdir -p "$test_dir/input/sub"
printf '%s' hello > "$test_dir/input/a.txt"
touch "$test_dir/input/sub/mangen.c"

printf '%s\n' \
    'a.txt : 4F9F2CAB' \
    'sub/mangen.c : 811C9DC5' > "$test_dir/expected.txt"

# Проверяем обход с указанным путём и без аргументов.
"$program" "$test_dir/input" > "$test_dir/with-path.txt"
(cd "$test_dir/input" && "$program") > "$test_dir/default.txt"

sort "$test_dir/expected.txt" > "$test_dir/expected.sorted"
for output in with-path default; do
    sort "$test_dir/$output.txt" > "$test_dir/actual.sorted"
    diff -u "$test_dir/expected.sorted" "$test_dir/actual.sorted"
done

# Проверяем справку и версию с путём и без него.
"$program" -h > "$test_dir/help.txt"
"$program" "$test_dir/input" -h > "$test_dir/help-with-path.txt"
diff -u "$test_dir/help.txt" "$test_dir/help-with-path.txt"
grep -Fq -- '-h' "$test_dir/help.txt"
grep -Fq -- '-v' "$test_dir/help.txt"

"$program" -v > "$test_dir/version.txt"
"$program" "$test_dir/input" -v > "$test_dir/version-with-path.txt"
diff -u "$test_dir/version.txt" "$test_dir/version-with-path.txt"
grep -Eq '^mangen[[:space:]]+[^[:space:]]' "$test_dir/version.txt"

if grep -Eq ' : [[:xdigit:]]{8}$' "$test_dir/help.txt" "$test_dir/version.txt"; then
    printf '%s\n' 'Ошибка: -h или -v вывел манифест.' >&2
    exit 1
fi

# Несуществующий каталог должен дать ненулевой код и сообщение в stderr.
if "$program" "$test_dir/missing" > "$test_dir/error.out" 2> "$test_dir/error.err"; then
    printf '%s\n' 'Ошибка: программа приняла несуществующий каталог.' >&2
    exit 1
fi

test ! -s "$test_dir/error.out"
test -s "$test_dir/error.err"

printf '%s\n' 'Все сквозные тесты прошли.'
